﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.DataModels
{
    public class tSupplier
    {
        public int Id { get; set; }
        public String Name { get; set; }
        public String NIP { get; set; }
        public DateTime CreationDate { get; set; }
    }
}
